﻿using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Songhay.Web.Controls.Extensions
{
    /// <summary>
    /// Extension methods for <see cref="System.Web.UI.Page"/>.
    /// </summary>
    public static class PageExtensions
    {
        /// <summary>
        /// Gets the conventional event argument
        /// from the current <see cref="System.Web.HttpRequest"/>.
        /// </summary>
        /// <param name="page">The page.</param>
        public static string GetEventArgument(this Page page)
        {
            return page.Request.Params["__EVENTARGUMENT"];
        }

        /// <summary>
        /// Gets the conventional event target
        /// from the current <see cref="System.Web.HttpRequest"/>.
        /// </summary>
        /// <param name="page">The page.</param>
        public static string GetEventTarget(this Page page)
        {
            return page.Request.Params["__EVENTTARGET"];
        }

        /// <summary>
        /// Gets the hidden field value from previous page.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="hiddenFieldId">The hidden field id.</param>
        /// <param name="saveInCurrentPage">if set to <c>true</c> [save in current page].</param>
        public static string GetHiddenFieldValueFromPreviousPage(this Page page, string hiddenFieldId, bool saveInCurrentPage = false)
        {
            string s = null;
            var hidden = default(HiddenField);
            var master = page.GetRootMaster();
            var currentControl = (master as Control)?? (page as Control);

            if(saveInCurrentPage)
            {
                hidden = currentControl.FindControl<HiddenField>(hiddenFieldId);
                if (hidden == null) return s;
            }

            if (page.IsReallyCrossPagePostBack())
            {
                master = page.PreviousPage.GetRootMaster();
                var previousControl = (master as Control) ?? (page.PreviousPage as Control);
                var previousHidden = previousControl.FindControl<HiddenField>(hiddenFieldId);
                if (previousHidden != null)
                {
                    s = previousHidden.Value;
                    if(hidden != default(HiddenField))hidden.Value = s;
                }
            }
            return s;
        }

        /// <summary>
        /// Gets the root Master Page.
        /// </summary>
        /// <param name="page">The page.</param>
        public static MasterPage GetRootMaster(this Page page)
        {
            var master = page.Master;
            while((master != null) && (master.Master != null))
            {
                master = master.Master;
            }
            return master;
        }

        /// <summary>
        /// Determines whether the specified page has a parameter.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="key">The key.</param>
        /// <returns>
        /// 	<c>true</c> if the specified page has parameter; otherwise, <c>false</c>.
        /// </returns>
        public static bool HasParameter(this Page page, string key)
        {
            if(string.IsNullOrEmpty(key)) return false;
            return (page.Request.Params.Keys.OfType<string>()
                .Where(k=>k.ToLower().Equals(key.ToLower())).Count() > 0);
        }

        /// <summary>
        /// Determines whether the specified <see cref="System.String"/> is the conventional event argument.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="argument">The argument.</param>
        /// <returns>
        /// 	<c>true</c> if the specified <see cref="System.String"/> is the conventional event argument; otherwise, <c>false</c>.
        /// </returns>
        public static bool HasEventArgument(this Page page, string argument)
        {
            if(string.IsNullOrEmpty(argument)) return false;

            var currentArgument = page.GetEventArgument();
            return currentArgument.ToLower().Equals(argument.ToLower());
        }

        /// <summary>
        /// Determines whether the specified <see cref="System.String"/> is the conventional event target.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="target">The argument.</param>
        /// <returns>
        /// 	<c>true</c> if the specified <see cref="System.String"/> is the conventional event target; otherwise, <c>false</c>.
        /// </returns>
        public static bool HasEventTarget(this Page page, string target)
        {
            if(string.IsNullOrEmpty(target)) return false;

            var currentTarget = page.GetEventTarget();
            return currentTarget.ToLower().Equals(target.ToLower());
        }

        /// <summary>
        /// Determines whether the previous page is of the specified type.
        /// </summary>
        /// <typeparam name="TPage">The type of the page.</typeparam>
        /// <param name="page">The page.</param>
        /// <returns>
        /// 	<c>true</c> if [is previous page of type] [the specified page]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsPreviousPageOfType<TPage>(this Page page) where TPage: Page
        {
            if(page.PreviousPage == null) return false;
            return (page.PreviousPage is TPage);
        }

        /// <summary>
        /// Determines whether there is a cross-page PostBack.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <returns>
        ///     <c>true</c> if there is a cross-page PostBack; otherwise, <c>false</c>.
        /// </returns>
        /// <remarks>
        /// “IsCrossPagePostback is only set on Page objects when they refer to the previous page and are accessed from the PreviousPage property…”
        /// —Alex Thissen [http://www.alexthissen.nl/blogs/main/archive/2006/09/13/beware-the-iscrosspagepostback-property.aspx]
        /// </remarks>
        public static bool IsReallyCrossPagePostBack(this Page page)
        {
            var previousPage = page.PreviousPage;
            return ((previousPage != null) && previousPage.IsCrossPagePostBack);
        }

        /// <summary>
        /// Traces the specified page.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="context">The context.</param>
        /// <param name="message">The message.</param>
        /// <param name="category">The title.</param>
        /// <remarks>
        /// Browse to ~/Trace.axd to see page with Trace output.
        /// </remarks>
        public static void WriteTrace(this Page page, HttpContext context, string message, string category = null)
        {
#if DEBUG
            if(context == null) return;
            if(string.IsNullOrEmpty(category)) category = string.Format("Page: {0}", page.GetType().Name);
            context.Trace.Write(category, message);
#endif
        }
    }
}
