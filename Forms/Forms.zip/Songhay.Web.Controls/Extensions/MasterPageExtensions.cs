﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

namespace Songhay.Web.Controls.Extensions
{
    /// <summary>
    /// Extension methods for <see cref="System.Web.UI.MasterPage"/>.
    /// </summary>
    public static class MasterPageExtensions
    {
        /// <summary>
        /// Finds the control in the current <see cref="System.Web.UI.MasterPage"/>.
        /// </summary>
        /// <typeparam name="TControl">The type of the control.</typeparam>
        /// <param name="master">The master.</param>
        /// <param name="controlId">The control id.</param>
        /// <returns></returns>
        public static TControl FindControl<TControl>(this MasterPage master, string controlId) where TControl: Control
        {
            var control = master as Control;
            return control.FindControl<TControl>(controlId);
        }

        /// <summary>
        /// Finds the control in the current <see cref="System.Web.UI.MasterPage"/>
        /// with respect to its Naming Container.
        /// </summary>
        /// <typeparam name="TControl">The type of the control.</typeparam>
        /// <param name="master">The master.</param>
        /// <param name="namingContainerPath">The Naming Container path to the control (see remarks).</param>
        /// <param name="controlId">The control id.</param>
        /// <remarks>
        /// A Naming Container path is one or more control IDs separated by `$`.
        /// 
        /// “Assuming our Content Place Holder ID is named "Content" you can then put that in FindControl
        /// followed by either $ or : and then the control you want to find. this.Master.FindControl("Content$ControlID")
        /// OR this.Master.FindControl("Content:ControlID")…”
        /// —Robert MacLean [http://www.sadev.co.za/content/findcontrol-and-master-pages]
        /// </remarks>
        public static TControl FindControl<TControl>(this MasterPage master, string namingContainerPath, string controlId) where TControl : Control
        {
            var id = namingContainerPath + '$' + controlId;
            return master.FindControl<TControl>(id);
        }
    }
}
