﻿using System;
using System.Web.UI;

namespace Songhay.Web.Controls.Extensions
{
    /// <summary>
    /// Extension methods for <see cref="System.Web.UI.Control"/>.
    /// </summary>
    public static class ControlExtensions
    {
        /// <summary>
        /// Finds the control in the current Naming Container.
        /// </summary>
        /// <typeparam name="TControl">The type of the control.</typeparam>
        /// <param name="control">The control.</param>
        /// <param name="controlId">The control id.</param>
        public static TControl FindControl<TControl>(this Control control, string controlId) where TControl: Control
        {
            var result = control.FindControl(controlId);
            if(result != null) return result as TControl;
            else return null;
        }
    }
}
