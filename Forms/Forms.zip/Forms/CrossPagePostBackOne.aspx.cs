﻿
namespace Songhay.Web.HostRoot.Forms
{
    public partial class CrossPagePostBackOne : System.Web.UI.Page { }
}