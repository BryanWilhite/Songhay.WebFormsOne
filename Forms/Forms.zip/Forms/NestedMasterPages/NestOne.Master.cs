﻿using System;

namespace Songhay.Web.HostRoot.Forms.NestedMasterPages
{
    public partial class NestOne : System.Web.UI.MasterPage
    {
    }
}