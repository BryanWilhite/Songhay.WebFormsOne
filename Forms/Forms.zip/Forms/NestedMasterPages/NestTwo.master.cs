﻿using System;

namespace Songhay.Web.HostRoot.Forms.NestedMasterPages
{
    public partial class NestTwo : System.Web.UI.MasterPage
    {
    }
}